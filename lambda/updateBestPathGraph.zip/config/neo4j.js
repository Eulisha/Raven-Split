const neo4j = require('neo4j-driver');
const host = 'bolt://172.31.29.201/:7687';
const user = 'neo4j';
const password = '5ps93';
const driver = neo4j.driver(host, neo4j.auth.basic(user, password));

module.exports = { driver, neo4j };
