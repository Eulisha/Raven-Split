const mysql = require('mysql2');

DB_HOST = 'database-raven-split.cb19cft9toek.ap-northeast-1.rds.amazonaws.com';
DB_PORT = 3306;
DB_USER = 'admin';
DB_PASS = '%P5js93t86';
DB_NAME = 'raven_split';

const connection = mysql.createPool({
  host: DB_HOST,
  port: DB_PORT,
  user: DB_USER,
  password: DB_PASS,
  database: DB_NAME,
  dateStrings: 'date',
});

const pool = connection.promise();

module.exports = pool;
